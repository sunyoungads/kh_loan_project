package org.zerock.mapper;

public class BoardMapperTest {

}
