package org.zerock.dao;

import java.util.List;

import org.zerok.vo.MemberEntity;


public interface MemberMapper {
	public List<MemberEntity> listmember();
}

