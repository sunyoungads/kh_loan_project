package org.zerock.dao;

import java.util.List;

import org.zerok.vo.DeptEntity;


public interface DeptMapper {
	public List<DeptEntity> listDept();
}

