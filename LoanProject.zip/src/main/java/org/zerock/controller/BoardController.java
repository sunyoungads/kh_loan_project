package org.zerock.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.zerock.dao.BoardMapper;
import org.zerok.vo.BoardEntity;

import java.util.List;


@Controller
@RequestMapping("/board/")

public class BoardController {

	@Autowired
	private BoardMapper boardMapper;
	
	@RequestMapping("/list")
	public String board(Model model) {
		System.out.println("*** /board/list ");
		List<BoardEntity> list = boardMapper.listboard();
		model.addAttribute("list",list);
		return "oracle/board";
		
	}
	
}

