package org.zerok.vo;

import lombok.Data;


@Data
public class DeptEntity {
	Integer deptno;
	String dname;
	String loc;
	
	
	
}
