package org.zerok.vo;

import lombok.Data;

@Data
public class BoardEntity {
	
	String cid;
	String pw;
	String dname;
	String Email;
	
	
}
