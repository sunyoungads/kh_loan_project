package org.zerok.vo;

import lombok.Data;

@Data
public class ReviewEntity {

	int iNum;
	String userID;
	String cont;
	java.sql.Date regDate;
	int rating;
	int viewCnt;
	
}
