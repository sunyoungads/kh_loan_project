package org.zerok.vo;

import lombok.Data;


@Data
public class MemberEntity {
	Integer deptno;
	String dname;
	String loc;
	
	
	
}
