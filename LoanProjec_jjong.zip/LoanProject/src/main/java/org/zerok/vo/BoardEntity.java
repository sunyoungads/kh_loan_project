package org.zerok.vo;

import lombok.Data;

@Data
public class BoardEntity {
	
	int boNum;
	String userID;
	String pw;
	String title;
	java.sql.Date regDate;
	int viewCnt;
	byte[] aType;
	byte[] bType;
	
}
