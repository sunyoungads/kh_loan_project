package org.zerok.vo;

import lombok.Data;

@Data
public class BascketEntity {
	
	String userID;
	int iNum;
	String status;
	java.sql.Date regDate;
	
}
