package org.zerok.vo;

import lombok.Data;

@Data
public class VdetailsEntity {
	
	int iNum;
	long rate;
	String institution;
	String aUse;
	java.sql.Date aPeriod;
	String way;
	long aStandard;
	String ccon;
	String area;
	String imformation;
	String aSite;
	int cNum;
	String etc;
	
}
