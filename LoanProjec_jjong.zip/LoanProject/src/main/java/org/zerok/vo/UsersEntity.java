package org.zerok.vo;

import lombok.Data;

@Data
public class UsersEntity {
	
	String userID;
	String pw;
	String email;
	String nName;
	String address;
	String name;
	int sNum;
	int pNum;
	int bNum;
	String grade;
	
}
