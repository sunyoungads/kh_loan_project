package org.zerok.vo;

import lombok.Data;

@Data
public class LoanProductEntity {
	
	int iNum;
	String loanprod;
	int llimit;
	String aTarget;
	String fund;
	int amount;
	int age;
	String catg;
	java.sql.Date aDate;
	
}
