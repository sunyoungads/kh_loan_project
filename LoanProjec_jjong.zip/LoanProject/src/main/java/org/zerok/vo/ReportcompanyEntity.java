package org.zerok.vo;

import lombok.Data;

@Data
public class ReportcompanyEntity {
	
	String userID;
	int iNum;
	int rNum;
	String rCont;
	int cNum;
	
}
