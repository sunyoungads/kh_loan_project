package org.zerok.vo;

public class ConnectsEntity {
	String userID;
	Integer iNum;
	String bankName;
	String staff;
	String email;
	String log;
	String test;

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public Integer getiNum() {
		return iNum;
	}

	public void setiNum(Integer iNum) {
		this.iNum = iNum;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getStaff() {
		return staff;
	}

	public void setStaff(String staff) {
		this.staff = staff;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLog() {
		return log;
	}

	public void setLog(String log) {
		this.log = log;
	}

	public String getTest() {
		return test;
	}

	public void setTest(String test) {
		this.test = test;
	}

	@Override
	public String toString() {
		return "ConnectsEntity [userID=" + userID + ", iNum=" + iNum + ", bankName=" + bankName + ", staff=" + staff
				+ ", email=" + email + ", log=" + log + ", test=" + test + "]";
	}

}
