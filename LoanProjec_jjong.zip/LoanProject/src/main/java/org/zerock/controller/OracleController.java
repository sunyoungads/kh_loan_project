package org.zerock.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.zerock.dao.DeptMapper;
import org.zerok.vo.DeptEntity;

import java.util.List;

@Controller
@RequestMapping("/oracle/")

public class OracleController {

	@Autowired
	private DeptMapper deptMapper;

	@RequestMapping("/dept")
	public String dept(Model model) {
		System.out.println("*** /oracle/dept ");
		List<DeptEntity> list = deptMapper.listDept();
		model.addAttribute("list", list);    // model 화면에 전달하는 객체. (key, value)로 전달됨.
		return "oracle/dept";
	}
}
