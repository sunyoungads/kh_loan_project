package org.zerock.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.zerock.dao.UsersMapper;
import org.zerok.vo.UsersEntity;

import java.util.List;


@Controller
@RequestMapping("/oracle/")

public class UsersController {

	@Autowired
	private UsersMapper UsersMapper;
	
	@RequestMapping("/users")
	public String board(Model model) {
		System.out.println("*** /oracle/users ");
		List<UsersEntity> list = UsersMapper.listusers();
		model.addAttribute("list",list);
		return "oracle/users";
		
	}
	
}

