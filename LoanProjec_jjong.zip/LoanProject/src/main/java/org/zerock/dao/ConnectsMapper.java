package org.zerock.dao;

import java.util.List;
import org.zerok.vo.ConnectsEntity;


public interface ConnectsMapper {
	public List<ConnectsEntity> listconnects();
}

