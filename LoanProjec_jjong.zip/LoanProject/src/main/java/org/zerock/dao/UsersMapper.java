package org.zerock.dao;

import java.util.List;


import org.zerok.vo.UsersEntity;


public interface UsersMapper {
	public List<UsersEntity> listusers();
}
