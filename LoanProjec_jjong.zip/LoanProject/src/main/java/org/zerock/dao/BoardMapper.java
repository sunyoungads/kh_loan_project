package org.zerock.dao;

import java.util.List;

import org.zerok.vo.BoardEntity;


public interface BoardMapper {
	public List<BoardEntity> listboard();
}
